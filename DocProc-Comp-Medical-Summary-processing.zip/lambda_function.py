import io
import os
import csv
import json
import boto3

s3 = boto3.client('s3')
BUCKET = os.environ['BUCKET']

def get_all_s3_keys(BUCKET,PROTOCOL_PATH):
    keys = []
    print('Here am in s3 get')
    #PROTOCOL_PATH = 'MH2103_N.pdf-analysis/2ab9fa50-87bd-11e9-8f9d-ba4200fb74e3'
    kwargs = {'Bucket': BUCKET,'Prefix': PROTOCOL_PATH }
    while True:
        resp = s3.list_objects_v2(**kwargs)
        
        print("print kwargs out")
        print(resp)
        print(PROTOCOL_PATH)
        
         
        for obj in resp['Contents']:
            if PROTOCOL_PATH in obj['Key']:
                print('path found')
                print(obj['Key'])
                if 'entities' in obj['Key']:
                    print("foound keys")
                    print(obj['Key'])
                    keys.append(obj['Key'])
                    print("printing the Path")
                    print(keys)
        try:
            kwargs['ContinuationToken'] = resp['NextContinuationToken']
        except KeyError:
            break
    print('out of loop')
    print(keys)
    return keys



def list_entity_paths(keys, PROTOCOL_PATH):
    entity_paths = []
    for key in keys:
        if PROTOCOL_PATH in key:
            if 'entities/' in key:
                # Extract path from object key
                ent_prefix = key.split('/')[:-1]
                ent_path = '/'.join(ent_prefix)
                # Exclude duplicates
                if ent_path not in entity_paths:
                    entity_paths.append(ent_path)
    print("printing paths")
    print(entity_paths)
    return entity_paths

def process_comprehend_medical_outputs(entity_paths,):
    for prefix in entity_paths:
        # Process the path
        protocol = prefix.split('/')[2]
        print('protocal')
        print(protocol)
        out_file = '{}-test-entities.csv'.format(protocol)
        out_prefix = prefix.split('entities')[0] + 'protocol_summary'
        summary_path = prefix.split('entities')[0] + 'labs_summary'
        all_named_tests_key = out_prefix + '/{}'.format(out_file)
        print('key')
        print(all_named_tests_key)
        newkey_csv = summary_path + '/{}'.format(out_file)
        ls_json = s3.list_objects_v2(Bucket=BUCKET, Prefix=prefix)['Contents']

        # Configure .csv file
        csv_data = io.StringIO()
        writer = csv.writer(csv_data)
        header = ['Protocol','Page','Id','BeginOffset','EndOffset','Score','Text','Category','Type','Traits','Attributes']
        writer.writerow(header)

        # Count named entities
        total_tests = 0
        total_named_tests = 0
        total_entities = 0

        for file in ls_json[0:]:
            counter = 0
            name = file['Key']
            print('protocal name')
            print(name)
            
            page = name.split('-')[-1].split('.')[0]
            text = s3.get_object(Bucket=BUCKET, Key=name)['Body']
            data = text.read().decode()
            json_data = json.loads(data)
            n_entities = len(json_data['Entities'])
            total_entities += n_entities

            # Count test entities
            n_tests = 0
            n_named_tests = 0
            for item in json_data['Entities'][0:]:
                if item['Category'] == 'TEST_TREATMENT_PROCEDURE':
                    n_tests += 1
                    if item['Type'] == 'TEST_NAME':
                        cols = [protocol, page]
                        vals = list(item.values())
                        cols.extend(vals)
                        writer.writerow(cols)
                        n_named_tests += 1

            total_tests += n_tests
            total_named_tests += n_named_tests

        # Upload .csv to s3
        s3.put_object(Body=csv_data.getvalue(), Bucket=BUCKET, Key=newkey_csv)

        # Calculate overall test percentage
        pct_tests = total_tests / total_entities
        pct_named_tests = total_named_tests / total_tests

        doc_summary = {}
        doc_summary['TotalEntities'] = total_entities
        doc_summary['TotalTests'] = total_tests
        doc_summary['TotalNamedTests'] = total_named_tests
        doc_summary['PercentTests'] = '{:.2%}'.format(pct_tests)
        doc_summary['PercentTestsNamed'] = '{:.2%}'.format(pct_named_tests)

        doc_summary_body = json.dumps(doc_summary, indent=4)
        doc_summary_key = out_prefix + '/{}-cm-output-summary.json'.format(protocol)
        s3.put_object(Body=doc_summary_body, Bucket=BUCKET, Key=doc_summary_key)


def lambda_handler(event, context):
    PROTOCOL_PATH = event['Records'][0]['Sns']['Message']
    print("printing path")
    print(PROTOCOL_PATH)
    print("printing event")
    print(event)
     
    keys = get_all_s3_keys(BUCKET,PROTOCOL_PATH)
    print("keys got from missing para")
    print(keys)
    print("printing path")
    print(PROTOCOL_PATH)
    #summary_path = PROTOCOL_PATH.split('/')[0] + "/"+"OUTPUT"+"/"+PROTOCOL_PATH.split('/')[2]
    #summary_path = PROTOCOL_PATH.split('/')[0] + "/"+"OUTPUT"+"/"
    entity_paths = []
    print(entity_paths)
    print("printing paths entity")
    entity_paths = list_entity_paths(keys, PROTOCOL_PATH)
    print("printing entity_paths")
    print(entity_paths)
    abc = process_comprehend_medical_outputs(entity_paths)
    print('Test entity and document summary files written.')
