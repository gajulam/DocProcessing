import os
import os.path
import sys
import json
import boto3
import botocore

root = os.environ["LAMBDA_TASK_ROOT"]
sys.path.insert(0, root)

# Comprehend Medical API
cm = boto3.client('comprehendmedical', use_ssl=True, region_name='us-east-1')

def get_named_entities(raw_txt):
    entities = cm.detect_entities(Text=raw_txt)
    json_output = json.dumps(entities, indent=4)
    return json_output

 
def lambda_handler(event, context):
    print("printing event")
    print(event)
    # Environment variables
    BUCKET = os.environ['BUCKET']
    TABLE = os.environ['MASTER_TABLE']
    PROTOCOL = event['Records'][0]['Sns']['Message']
  
    print(PROTOCOL)
    DOC_ID = PROTOCOL.split('/')[1]
    TXT_PREFIX = PROTOCOL + '/raw-text'

    # Connect AWS Services
    sns = boto3.client('sns')
    s3_r = boto3.client('s3')
    s3_w = boto3.resource('s3')
    ddb = boto3.resource('dynamodb').Table(TABLE)
    ls = s3_r.list_objects(Bucket=BUCKET, Prefix=TXT_PREFIX)['Contents']

    print("Protocol S3 Path:", PROTOCOL)
    print("boto3 version:", boto3.__version__)
    print("botocore version:", botocore.__version__)
    print("Writing pagewise JSON for Comprehend Medical detected entities...")

    # Write output files
    for s3_key in ls[0:]:
        s3_object = s3_key['Key']
        name = s3_object.split('.')[0].split('/')[-1]
        ent_out = PROTOCOL + '/entities/{}.json'.format(name)
        txt_file = s3_r.get_object(Bucket=BUCKET, Key=s3_object)
        raw_txt = txt_file['Body'].read().decode()
        all_entities = get_named_entities(raw_txt.replace('\n',' '))
        s3_w.Object(BUCKET, ent_out).put(Body=all_entities)

    print('Comprehend Medical entity detection complete.')
    print('Updating document status in {} table..'.format(TABLE))
    print('Publishing message to SNS topic to trigger next pipeline step.')

    # Publish protocol name for downstream Lambda
    sns.publish(
        TargetArn = os.environ['SNS_TOPIC_ARN'],
        Message = PROTOCOL
    )

    try:
        # Update table
        resp = ddb.update_item(
            Key = { "documentId": DOC_ID },
            UpdateExpression = \
            'SET documentStatus = :documentStatusValue',
            ConditionExpression = 'attribute_exists(documentId)',
            ExpressionAttributeValues = {
                ':documentStatusValue': "ENTITY_EXTRACTION_COMPLETE"
            }
        )
    except:
        print('Table update failed. Exiting...')
       

